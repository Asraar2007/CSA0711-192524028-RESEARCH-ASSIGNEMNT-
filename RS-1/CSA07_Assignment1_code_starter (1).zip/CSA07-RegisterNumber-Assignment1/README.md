# Computer Networks - Assignment 1

- Name: Hussain
- Register number: <fill in>
- Operating system: <fill in>
- Python version: <fill in, e.g. python --version>
- Packet Tracer / NS-3 version: <fill in>

## How to run
Tasks 3, 4, 7, 8 and 9 contain a Python 3 program each:

    cd Task03 && python task03_layers.py

The output of my run is saved next to each program in output.txt.

## Result of each task (fill in one line per task after you run it)
- Task 1: ...
- Task 2: ...

## Commit history
Commit after finishing each task (one commit per task at least), for example:

    git add Task03 && git commit -m "Task 3: layer wrapping program and overhead calculation"
