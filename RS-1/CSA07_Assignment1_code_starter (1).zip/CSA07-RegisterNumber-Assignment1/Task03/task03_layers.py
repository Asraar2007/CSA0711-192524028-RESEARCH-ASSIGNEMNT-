"""How data is wrapped by each layer at the sender and unwrapped at the receiver."""
LAYERS = [("Application", "HTTP"), ("Transport", "TCP"), ("Network", "IP"),
          ("Data link", "ETH")]

def send(message):
    pdu = message
    for layer, tag in LAYERS:
        # TODO 1 (completed): wrap pdu with this layer's header and trailer
        trailer = "|FCS]" if tag == "ETH" else "]"
        pdu = "[" + tag + "|" + pdu + trailer
        print(f"{layer} adds {tag} -> {len(pdu)} bytes")
    return pdu

def receive(frame):
    pdu = frame
    for layer, tag in reversed(LAYERS):
        head = "[" + tag + "|"
        tail = "|FCS]" if tag == "ETH" else "]"
        assert pdu.startswith(head) and pdu.endswith(tail), f"{layer}: bad header"
        pdu = pdu[len(head):-len(tail)]
    return pdu

frame = send("GET /results")
print("on the wire:", frame)
print("delivered :", receive(frame))
print(f"overhead : {len(frame) - len('GET /results')} bytes for 12 bytes of data")

# extra part of the question: 1,400-byte message
big = "x" * 1400
f2 = send(big)
ov = len(f2) - len(big)
print(f"\n1,400-byte message: overhead {ov} bytes = {ov/len(f2):.2%} of the frame")
small = len(frame) - 12
print(f"12-byte message   : overhead {small} bytes = {small/len(frame):.2%} of the frame")
