"""CRC error detection for frames sent between two switches."""

def mod2_div(dividend, divisor):
    """Return the remainder of modulo-2 (XOR) division of two bit strings."""
    rem = list(dividend)
    for i in range(len(dividend) - len(divisor) + 1):
        # TODO 1 (completed): if the leading bit is 1, XOR the divisor in at position i
        if rem[i] == "1":
            for j in range(len(divisor)):
                rem[i + j] = "0" if rem[i + j] == divisor[j] else "1"
    return "".join(rem[-(len(divisor) - 1):])

def encode(data, gen):
    crc = mod2_div(data + "0" * (len(gen) - 1), gen)
    return data + crc

def check(frame, gen):
    return set(mod2_div(frame, gen)) == {"0"}

GEN = "1011"  # x^3 + x + 1
frame = encode("1101011011", GEN)
print("transmitted:", frame)
print("no error :", check(frame, GEN))
bad = frame[:4] + ("1" if frame[4] == "0" else "0") + frame[5:]
print("1-bit error:", check(bad, GEN))
burst = frame[:2] + "".join("1" if b == "0" else "0" for b in frame[2:5]) + frame[5:]
print("3-bit burst:", check(burst, GEN))

# extra parts of the question
print("\nremainder of the received frame 1101011011101 :", mod2_div("1101011011101", GEN))

def flip(frame, positions):
    f = list(frame)
    for p in positions:
        f[p] = "1" if f[p] == "0" else "0"
    return "".join(f)

print("\nTwo-bit errors that GEN 1011 cannot detect (positions counted from the left, 0-based):")
for i in range(len(frame)):
    for j in range(i + 1, len(frame)):
        if check(flip(frame, (i, j)), GEN):
            print(f"  bits {i} and {j} (distance {j-i}) -> accepted although corrupted")

print("\nFour-bit error patterns that CRC-3 cannot detect:")
undetected_crc, undetected_par = [], []
n = len(frame)
from itertools import combinations
for combo in combinations(range(n), 4):
    if check(flip(frame, combo), GEN):
        undetected_crc.append(combo)
print("  number of 4-bit patterns CRC-3 misses:", len(undetected_crc), "of", len(list(combinations(range(n), 4))))
print("  example:", undetected_crc[0], flip("0"*n, undetected_crc[0]))

# comparison with even parity over the 13-bit frame
def parity_ok(bits):
    return bits.count("1") % 2 == 0
pf = frame + ("1" if frame.count("1") % 2 else "0")
def pflip(positions):
    return parity_ok(flip(pf, positions))
tests = {
 "2-bit adjacent (bits 11,12)": (11, 12),
 "2-bit, 7 apart (bits 4,11)": (4, 11),
 "4-bit 0000000001111 (bits 9-12)": (9, 10, 11, 12),
 "4-bit 0000000011101 (bits 8,9,10,12)": (8, 9, 10, 12),
 "3-bit 0000000001011 (bits 9,11,12)": (9, 11, 12),
}
print("\nPattern                                  CRC-3 (1011)   even parity")
for name, pos in tests.items():
    crc_res = "detected" if not check(flip(frame, pos), GEN) else "MISSED"
    par_res = "detected" if not pflip(pos) else "MISSED"
    print(f"{name:<40} {crc_res:<14} {par_res}")
