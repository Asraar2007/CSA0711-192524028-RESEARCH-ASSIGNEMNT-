"""Hamming(7,4) code: correct a single-bit error in a 4-bit sensor reading."""

def encode(d):  # d = [d1, d2, d3, d4]
    p1 = d[0] ^ d[1] ^ d[3]
    p2 = d[0] ^ d[2] ^ d[3]
    p3 = d[1] ^ d[2] ^ d[3]
    return [p1, p2, d[0], p3, d[1], d[2], d[3]]  # positions 1..7

def decode(c):
    # TODO 1 (completed)
    c = c[:]
    s1 = c[0] ^ c[2] ^ c[4] ^ c[6]
    s2 = c[1] ^ c[2] ^ c[5] ^ c[6]
    s3 = c[3] ^ c[4] ^ c[5] ^ c[6]
    pos = s1 + 2 * s2 + 4 * s3
    if pos:
        c[pos - 1] ^= 1
    return pos, [c[2], c[4], c[5], c[6]]

word = encode([1, 0, 1, 1])
print("codeword :", "".join(map(str, word)))
for flip in (None, 5):
    rx = word[:]
    if flip:
        rx[flip - 1] ^= 1
    pos, data = decode(rx)
    print(f"error at {str(flip):<4}: syndrome {pos}, data {''.join(map(str, data))}")

# extra: the codeword 0110011 received as 0110111
rx = [int(b) for b in "0110111"]
pos, data = decode(rx)
print("\n0110111 -> syndrome", pos, "data", "".join(map(str, data)))

# extra: two errors fool the decoder
print("\nTwo-bit errors:")
for a, b in [(3, 5), (1, 2), (2, 6)]:
    rx = word[:]
    rx[a - 1] ^= 1
    rx[b - 1] ^= 1
    pos, data = decode(rx)
    print(f"  flipped positions {a} and {b}: syndrome {pos} (decoder flips position {pos}), "
          f"data {''.join(map(str, data))}, original data 1011 -> {'wrong' if data != [1,0,1,1] else 'ok'}")

# extra: FEC vs ARQ at BER 1e-3
ber = 1e-3
p_ok21 = (1 - ber) ** 21
p_one21 = 21 * ber * (1 - ber) ** 20
p_fail_fec = 1 - p_ok21 - p_one21
print(f"\nFEC: 21 bits per reading, P(2 or more errors) = {p_fail_fec:.6f}, "
      f"average extra delay = {p_fail_fec/(1-p_fail_fec)*40:.4f} ms")
p_err16 = 1 - (1 - ber) ** 16
tries = 1 / (1 - p_err16)
print(f"ARQ: 16 bits per attempt, P(error) = {p_err16:.5f}, average attempts = {tries:.5f}, "
      f"average bits = {16*tries:.3f}, average extra delay = {(tries-1)*40:.3f} ms")
