"""Link utilisation of stop-and-wait and sliding-window protocols on different links."""
import math

def utilisation(frame_bits, rate_bps, distance_m, window, speed=2e8):
    tx = frame_bits / rate_bps      # transmission time
    prop = distance_m / speed       # propagation time
    # TODO 1 (completed)
    a = prop / tx
    return min(1.0, window / (1 + 2 * a)), a

links = [("Campus LAN, 200 m, 1 Gbps", 1e9, 200),
         ("City fibre, 50 km, 1 Gbps", 1e9, 50_000),
         ("Satellite, 36,000 km, 10 Mbps", 10e6, 36_000_000)]
for name, rate, dist in links:
    u1, a = utilisation(12_000, rate, dist, 1)
    u7, _ = utilisation(12_000, rate, dist, 7)
    u127, _ = utilisation(12_000, rate, dist, 127)
    print(f"{name:<31} a = {a:7.2f} stop-and-wait {u1:6.1%} "
          f"W=7 {u7:6.1%} W=127 {u127:6.1%}")

# extra: smallest window for 100 % and sequence-number bits
def window_needed(a):
    return math.ceil(1 + 2 * a)

for name, rate, dist in links[1:] + [("Head office, 400 km, 1 Gbps", 1e9, 400_000)]:
    _, a = utilisation(12_000, rate, dist, 1)
    w = window_needed(a)
    gbn = math.ceil(math.log2(w + 1))
    sr = math.ceil(math.log2(2 * w))
    print(f"{name:<31} a = {a:7.2f} window needed = {w:4d}  GBN bits = {gbn}  SR bits = {sr}")

# head-office link, selective repeat with window 64
u, a = utilisation(12_000, 1e9, 400_000, 64)
print(f"\nHead office, window 64: utilisation {u:.2%}, throughput {u*1000:.1f} Mbps, "
      f"receiver buffer {64*1500} bytes")
u1, _ = utilisation(12_000, 1e9, 400_000, 1)
print(f"Head office, stop-and-wait: utilisation {u1:.3%}, throughput {u1*1000:.2f} Mbps")
