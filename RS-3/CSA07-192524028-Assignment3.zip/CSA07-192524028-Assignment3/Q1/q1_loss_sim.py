"""Simulated delivery of UDP and TCP at 1%, 5%, 10% loss (stand-in for tc netem)."""
import random
random.seed(1)
N, RTT, PPS = 10_000, 0.060, 500
print("loss | UDP delivered | UDP lost | TCP delivered | TCP stalls | TCP time vs ideal")
for p in (0.01, 0.05, 0.10):
    udp_ok = sum(random.random() > p for _ in range(N))
    t_ideal = N / PPS
    stalls = sum(random.random() < p for _ in range(N))   # each loss = one retransmission
    stall_time = stalls * (RTT + 3 / PPS)
    print(f"{p:4.0%} | {udp_ok:6d} ({udp_ok/N:6.2%}) | {N-udp_ok:5d} | {N:6d} (100%) "
          f"| {stalls:4d} = {stall_time:5.1f} s | {t_ideal:.0f} s -> {t_ideal+stall_time:.0f} s")
