"""Q1 calculations: header overhead and the 'live video over TCP' freeze estimate."""
payload = 100
udp_hdr, tcp_hdr, ip_hdr = 8, 20, 20
for name, h in (("UDP", udp_hdr), ("TCP", tcp_hdr)):
    total = payload + h + ip_hdr
    print(f"{name}: headers {h+ip_hdr} B, packet {total} B, "
          f"overhead = {100*(h+ip_hdr)/total:.1f}% of the packet "
          f"({100*(h+ip_hdr)/payload:.0f}% of the payload)")

# Alternative concept: video over TCP
loss, rtt, pps = 0.02, 0.060, 500
lost_per_min = pps * 60 * loss
dupack_wait = 3 / pps                    # time to collect 3 duplicate ACKs
freeze = rtt + dupack_wait               # fast retransmit; RTO would be longer
print(f"packets/min {pps*60}, lost/min {lost_per_min:.0f}  (one every {60/lost_per_min*1000:.0f} ms)")
print(f"freeze per loss >= {rtt*1000:.0f} ms (about {freeze*1000:.0f} ms with fast retransmit)")
print(f"frozen time if losses did not overlap: {lost_per_min*freeze:.1f} s per minute")
