"""TCP congestion window over 20 round trips: slow start, avoidance and loss."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def simulate(losses, ssthresh=16, reno=True):
    cwnd, trace = 1, []
    for rtt in range(1, 21):
        trace.append(cwnd)
        # TODO 1 (done)
        if rtt in losses:
            ssthresh = max(cwnd // 2, 2)
            cwnd = ssthresh if reno else 1
        elif cwnd < ssthresh:
            cwnd = min(cwnd * 2, ssthresh)
        else:
            cwnd += 1
    return trace


results = {}
for label, reno in (("Reno ", True), ("Tahoe", False)):
    tr = simulate({8, 14}, reno=reno)
    results[label.strip()] = tr
    print(label, " ".join(f"{w:2d}" for w in tr), f"| segments sent {sum(tr)}")
print("Extra segments delivered by Reno:", sum(results["Reno"]) - sum(results["Tahoe"]))

# throughput at RTT 7 (cwnd = 18 segments, MSS 1460 B, RTT 40 ms)
cwnd7, mss, rtt = 18, 1460, 0.040
bps = cwnd7 * mss * 8 / rtt
print(f"Throughput at RTT 7 = {cwnd7}x{mss} B / 40 ms = {bps/1e6:.3f} Mbps ({bps/8:,.0f} B/s)")

# Mathis model for BBR-vs-Reno alternative: rate = 1.22*MSS/(RTT*sqrt(p))
for p in (0.0001, 0.001, 0.01):
    r = 1.22 * mss * 8 / (rtt * p ** 0.5)
    print(f"Reno at random loss p={p:g}: average window {1.22/p**0.5:6.1f} seg -> {r/1e6:7.2f} Mbps")

x = range(1, 21)
plt.figure(figsize=(7, 3.6))
plt.plot(x, results["Reno"], "o-", label="Reno (fast recovery)")
plt.plot(x, results["Tahoe"], "s--", label="Tahoe (back to 1)")
for r in (8, 14):
    plt.axvline(r, color="grey", lw=0.8, ls=":")
plt.xlabel("Round trip"); plt.ylabel("cwnd (segments)")
plt.title("Tahoe vs Reno, losses at RTT 8 and 14"); plt.legend(); plt.grid(alpha=.3)
plt.tight_layout(); plt.savefig("q2_cwnd.png", dpi=170)
