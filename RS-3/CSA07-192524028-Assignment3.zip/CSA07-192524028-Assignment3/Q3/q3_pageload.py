"""Page-load time models: 1 HTML + 80 objects, RTT 50 ms, transmission time negligible."""
import math
RTT, OBJ = 0.050, 80


def show(name, rtts):
    print(f"{name:<52} {rtts:6.0f} RTT = {rtts*RTT*1000:7.0f} ms")
    return rtts * RTT


def models(n_obj, par=6):
    total = n_obj + 1
    return {
        "Non-persistent, serial": 2 * total,
        "Persistent HTTP/1.1, no pipelining": 1 + total,
        "Persistent HTTP/1.1, pipelining (or HTTP/2)": 1 + 1 + 1,
        f"{par} parallel non-persistent": 2 + 2 * math.ceil(n_obj / par),
    }


print("--- 80 objects")
for k, v in models(OBJ).items():
    show(k, v)
print("--- 80 objects bundled into 8 bundles (9 objects with the HTML)")
for k, v in models(8).items():
    show(k, v)
print("--- Second visit")
print("Cache-Control max-age valid: 0 requests = 0 ms")
show("ETag/If-None-Match (304) with pipelining", 3)
show("ETag/If-None-Match (304), persistent no pipelining", 82)
