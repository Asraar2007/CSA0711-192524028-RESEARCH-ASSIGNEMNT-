"""Iterative DNS resolution through root, TLD and authoritative servers (with TTL cache)."""
import time

SERVERS = {
    "root": {"in.": "tld-in", "com.": "tld-com"},
    "tld-in": {"ac.in.": "ns-ac"},
    "tld-com": {"example.com.": "ns-example"},
    "ns-ac": {"simats.ac.in.": "ns-simats"},
    "ns-simats": {"results.simats.ac.in.": "10.20.30.40"},
    "ns-example": {"www.example.com.": "93.184.216.34"},
}
TTL = 300                 # seconds an answer may stay in the cache
cache = {}                # name -> (ip, expiry time)
clock = time.time         # replaced by a fake clock in the demo below


def resolve(name):
    if name in cache and cache[name][1] > clock():     # fresh entry -> no queries
        return cache[name][0], 0
    server, queries = "root", 0
    while True:
        queries += 1
        # TODO 1 (done): longest key that name ends with
        zone = max((k for k in SERVERS[server] if name.endswith(k)), key=len)
        value = SERVERS[server][zone]
        if any(ch.isdigit() for ch in value):          # looks like an IP address
            cache[name] = (value, clock() + TTL)
            return value, queries
        server = value


for n in ("results.simats.ac.in.", "www.example.com.", "results.simats.ac.in."):
    ip, q = resolve(n)
    print(f"{n:<24} {ip:<15} queries sent: {q}")

print("--- TTL demo with a fake clock")
now = [0.0]
clock = lambda: now[0]
cache.clear()
for t in (0, 100, 299, 301, 302):
    now[0] = t
    ip, q = resolve("results.simats.ac.in.")
    print(f"t={t:3d}s  {ip}  queries sent: {q}")

print("--- Load on the authoritative server")
RES = 40
for ttl in (300, 30):
    per = 3600 // ttl
    print(f"TTL {ttl:3d}s: {per:3d} queries/hour per resolver, {per*RES:5d}/hour for {RES} resolvers "
          f"(no caching would be 150000 look-ups)")
