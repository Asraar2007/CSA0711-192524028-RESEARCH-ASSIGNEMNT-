"""M/M/1 model of a router output link: arrivals at rate lam, service at rate mu."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


def mm1(lam, mu):
    # TODO 1 (done)
    if lam >= mu:
        return None
    rho = lam / mu
    L = rho / (1 - rho)
    W = 1 / (mu - lam)
    return rho, L, W


mu = 1000  # packets per second the link can send
for lam in (500, 800, 900, 950, 990, 1000):
    r = mm1(lam, mu)
    if r is None:
        print(f"load {lam:4d} pkt/s: unstable, queue grows without limit")
    else:
        rho, L, W = r
        print(f"load {lam:4d} pkt/s: rho {rho:.2f} L {L:6.1f} pkts "
              f"W {W * 1000:6.1f} ms")

print("--- extra answers")
print("Delay exceeds 20 ms when 1/(mu-lam) > 0.02 -> lam > %d pkt/s" % (mu - 1 / 0.02))
w450, w900 = mm1(450, mu)[2], mm1(900, mu)[2]
print(f"450 -> 900 pkt/s: W {w450*1000:.2f} ms -> {w900*1000:.1f} ms (x{w900/w450:.1f}); "
      f"L {mm1(450,mu)[1]:.2f} -> {mm1(900,mu)[1]:.1f} (x{mm1(900,mu)[1]/mm1(450,mu)[1]:.1f})")
print("Capacity for W < 10 ms at 1500 pkt/s: mu > %d pkt/s" % (1500 + 1 / 0.010))
print("Doubled link (mu=2000) at 1800 pkt/s: W = %.1f ms, L = %.1f" % (mm1(1800, 2000)[2] * 1000, mm1(1800, 2000)[1]))
print("Token bucket: 1 MB = 8 Mbit, drain = 10-2 = 8 Mbps -> burst %.1f s" % (8 / (10 - 2)))
print("Load 1200 pkt/s on 1000 pkt/s link: loss at least %.1f%%" % (100 * (1 - 1000 / 1200)))

xs = list(range(50, 991, 10))
ys = [mm1(x, mu)[2] * 1000 for x in xs]
plt.figure(figsize=(6.5, 3.4))
plt.plot(xs, ys)
plt.axhline(20, color="red", ls="--", lw=.8)
plt.text(60, 22, "20 ms", color="red")
plt.xlabel("Load (packets/s)"); plt.ylabel("Average delay (ms)")
plt.title("M/M/1 delay vs load (mu = 1000 pkt/s)"); plt.grid(alpha=.3)
plt.tight_layout(); plt.savefig("q5_delay_vs_load.png", dpi=170)
