"""FIFO vs strict-priority queue: video 300 pkt/s + backup 650 pkt/s on a 1000 pkt/s link."""
import random
random.seed(7)
MU, VID, BAK, N = 1000, 300, 650, 300_000


def arrivals(rate, cls, n):
    t, out = 0.0, []
    for _ in range(n):
        t += random.expovariate(rate)
        out.append((t, cls))
    return out


def run(priority):
    ev = sorted(arrivals(VID, 0, int(N * VID / (VID + BAK))) + arrivals(BAK, 1, int(N * BAK / (VID + BAK))))
    q = [[], []]; delays = {0: [], 1: []}
    t, i = 0.0, 0
    while i < len(ev) or q[0] or q[1]:
        if not q[0] and not q[1] and ev[i][0] > t:
            t = ev[i][0]
        while i < len(ev) and ev[i][0] <= t:
            q[ev[i][1]].append(ev[i][0]); i += 1
        if priority:
            c = 0 if q[0] else 1
        else:   # FIFO: oldest arrival first
            c = 0 if q[0] and (not q[1] or q[0][0] <= q[1][0]) else 1
        arr = q[c].pop(0)
        t += random.expovariate(MU)
        delays[c].append(t - arr)
    return {c: 1000 * sum(v) / len(v) for c, v in delays.items()}


for name, pr in (("FIFO", False), ("Strict priority (video first)", True)):
    d = run(pr)
    print(f"{name:<30} video delay {d[0]:6.2f} ms   backup delay {d[1]:6.2f} ms")
print("Theory FIFO: 1/(mu-lam) = %.1f ms for both" % (1000 / (MU - VID - BAK)))
R = (VID + BAK) / MU ** 2
print("Theory priority: video %.2f ms, backup %.1f ms" % (1000 * (R / (1 - VID / MU) + 1 / MU),
      1000 * (R / ((1 - VID / MU) * (1 - (VID + BAK) / MU)) + 1 / MU)))
