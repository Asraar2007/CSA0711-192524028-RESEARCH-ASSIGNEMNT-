"""Round trips before the first request byte, and the Wi-Fi -> 5G switch (RTT 100 ms)."""
RTT = 100
rows = [("TCP + TLS 1.2", 1 + 2), ("TCP + TLS 1.3", 1 + 1),
        ("QUIC, first visit", 1), ("QUIC 0-RTT resumption", 0)]
print(f"{'Protocol':<24}{'RTTs':>5}{'time before first request byte':>34}{'  first response byte':>22}")
for n, r in rows:
    print(f"{n:<24}{r:>5}{r*RTT:>31} ms{(r+1)*RTT:>19} ms")
print("--- Wi-Fi -> 5G switch (excluding loss-detection time)")
print("TCP + TLS 1.3 : new TCP (1 RTT) + new TLS (1 RTT) + range request (1 RTT) = %d ms" % (3 * RTT))
print("QUIC          : path validation (1 RTT) = %d ms" % RTT)
