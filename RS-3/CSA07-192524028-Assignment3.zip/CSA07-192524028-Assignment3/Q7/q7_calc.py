"""Telemedicine design numbers."""
win, rtt = 64 * 1024, 0.300
print(f"64 KB window, RTT 300 ms : {win*8/rtt/1e6:.2f} Mbps")
for mb in (5, 10, 30):
    print(f"  {mb:2d} MB X-ray at that rate : {mb*8e6/(win*8/rtt):6.0f} s")
mss = 1460
for p in (0.01, 0.05):
    r = 1.22 * mss * 8 / (rtt * p ** 0.5)
    print(f"Mathis limit, loss {p:.0%}, RTT 300 ms: {r/1e6:.2f} Mbps -> 10 MB in {80e6/r:5.0f} s")
for bw in (5, 10):
    print(f"BDP at {bw} Mbps, RTT 300 ms: {bw*1e6*rtt/8/1024:.0f} KB window needed")
r5 = win * 8 / 0.020
print(f"After 5G (RTT 20 ms): 64 KB window limit = {r5/1e6:.1f} Mbps")
