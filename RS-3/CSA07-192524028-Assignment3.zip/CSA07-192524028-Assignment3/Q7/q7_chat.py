"""Tiny reliable chat: line-based messages over TCP, server relays to all other clients."""
import socket, threading


def chat_server(host="127.0.0.1", port=9001, ready=None, stop=None):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port)); s.listen(5); s.settimeout(0.2)
    clients, lock = [], threading.Lock()
    if ready: ready.set()

    def handle(conn):
        f = conn.makefile("r", encoding="utf-8")
        for line in f:
            with lock:
                for o in clients:
                    if o is not conn:
                        o.sendall(line.encode())
        with lock:
            clients.remove(conn)
    while not (stop and stop.is_set()):
        try:
            conn, _ = s.accept()
        except socket.timeout:
            continue
        with lock:
            clients.append(conn)
        threading.Thread(target=handle, args=(conn,), daemon=True).start()
    s.close()
