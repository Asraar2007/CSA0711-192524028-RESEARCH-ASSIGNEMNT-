"""Chunked, checksummed file transfer over TCP (records / X-ray images)."""
import hashlib, os, socket, struct, sys, time

CHUNK = 64 * 1024


def serve(host="127.0.0.1", port=9000, out="received.bin", once=True):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    s.bind((host, port)); s.listen(1)
    conn, _ = s.accept()
    with conn:
        size, = struct.unpack("!Q", conn.recv(8, socket.MSG_WAITALL))
        digest = conn.recv(32, socket.MSG_WAITALL)
        h, got = hashlib.sha256(), 0
        with open(out, "wb") as f:
            while got < size:
                b = conn.recv(min(CHUNK, size - got))
                if not b: break
                f.write(b); h.update(b); got += len(b)
        ok = h.digest() == digest and got == size
        conn.sendall(b"OK" if ok else b"NO")
    s.close()
    return ok


def send(path, host="127.0.0.1", port=9000):
    data = open(path, "rb").read()
    t0 = time.time()
    c = socket.create_connection((host, port))
    c.sendall(struct.pack("!Q", len(data)) + hashlib.sha256(data).digest())
    for i in range(0, len(data), CHUNK):
        c.sendall(data[i:i + CHUNK])
    ok = c.recv(2) == b"OK"
    c.close()
    return ok, time.time() - t0


if __name__ == "__main__":
    if sys.argv[1] == "serve": print("integrity ok:", serve(port=int(sys.argv[2])))
    else: print(send(sys.argv[2], port=int(sys.argv[3])))
