"""Runs the file transfer and chat on loopback and prints the results."""
import os, socket, threading, time
from q7_filetransfer import serve, send
from q7_chat import chat_server

# --- file transfer: 8 MB random 'X-ray'
open("xray.bin", "wb").write(os.urandom(8 * 1024 * 1024))
res = {}
th = threading.Thread(target=lambda: res.update(ok=serve(port=9100, out="xray_received.bin")))
th.start(); time.sleep(0.3)
ok, secs = send("xray.bin", port=9100); th.join()
print(f"File transfer: 8 MB, sender says ok={ok}, receiver integrity={res['ok']}, time {secs:.3f} s (no impairment)")

# --- chat
ready, stop = threading.Event(), threading.Event()
threading.Thread(target=chat_server, kwargs=dict(port=9101, ready=ready, stop=stop), daemon=True).start()
ready.wait()
doc = socket.create_connection(("127.0.0.1", 9101)); nurse = socket.create_connection(("127.0.0.1", 9101))
time.sleep(0.2)
t0 = time.time()
doc.sendall(b"Doctor: please upload the chest X-ray\n")
print("Chat: nurse received ->", nurse.makefile().readline().strip(), f"({(time.time()-t0)*1000:.1f} ms)")
nurse.sendall(b"Nurse: uploaded, 8 MB\n")
print("Chat: doctor received ->", doc.makefile().readline().strip())
stop.set()
for f in ("xray.bin", "xray_received.bin"): os.remove(f)
