# CSA07-192524028-Assignment3 — Computer Networks, Assignment 3 (CO3)

- **Name:** H ASRAAR AHMED
- **Register number:** 192524028
- **Operating system:** <your OS and version>
- **Python version:** <python3 --version>
- **Packet Tracer / NS-3 version:** <version, if used>

## Folder layout
| Folder | Content | How to run |
|---|---|---|
| Q1 | sockets, overhead, loss model | `python3 q1_sockets.py`, `python3 q1_overhead_and_freeze.py`, `python3 q1_loss_sim.py` |
| Q2 | Tahoe vs Reno, plot | `python3 q2_cwnd.py` (writes `q2_cwnd.png`) |
| Q3 | page-load models | `python3 q3_pageload.py` |
| Q4 | iterative DNS with TTL cache | `python3 q4_dns.py` |
| Q5 | M/M/1, FIFO vs priority | `python3 q5_mm1.py`, `python3 q5_queue_sim.py` |
| Q6 | set-up time and migration | `python3 q6_setup_time.py` |
| Q7 | file transfer, chat, calculations | `python3 q7_calc.py`, `python3 q7_selftest.py` |

Each folder also has `commands.txt` (Wireshark / tc netem / iperf3 / dig / openssl commands) and `*.out.txt` (program output).
Put your own Wireshark captures (`.pcapng`) and screenshots in the same folder.

## Results (one line each)
- Q1: segments demultiplexed by 4-tuple (TCP) / port (UDP); UDP overhead 21.9 %, TCP 28.6 % for a 100-byte update.
- Q2: Reno delivers 211 segments in 20 RTTs, Tahoe 144 (67 more).
- Q3: 8.1 s (non-persistent), 4.1 s (persistent), 1.5 s (6 parallel), 0.15 s (pipelining / HTTP/2).
- Q4: 12 queries/h per resolver at TTL 300 s, 120 at TTL 30 s; recommended TTL 300 s.
- Q5: 20 ms delay at 950 pkt/s; strict priority gives video 2.4 ms against 22 ms in FIFO.
- Q6: 300 / 200 / 100 / 0 ms before the first request byte (TLS 1.2 / TLS 1.3 / QUIC / QUIC 0-RTT).
- Q7: 64 KB window at 300 ms RTT limits TCP to 1.75 Mbps; X-ray transfer verified with SHA-256.
